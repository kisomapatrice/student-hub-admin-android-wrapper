# Student Hub V1 Admin Android Wrapper — Appearance Update V1.1.1

This is the **complete Android Gradle project**, not a partial patch. It includes the root Gradle files (`settings.gradle`, `build.gradle`, `gradle.properties`) as well as the `app/` source. The navy-and-blue app icon, branded startup screen, and first-load retry state are included.

## Build through the existing GitHub Actions workflow

The repository's `Apply Student Hub Android Appearance Update` workflow expects a file named `Student_Hub_Admin_Android_Appearance_Update_V1.1.zip` in the repository root. Upload this complete ZIP using that exact filename, then manually run that workflow. It extracts this archive into the repository root, commits the updated source, and runs `gradle --no-daemon :app:assembleDebug` from the correct Gradle root.

## App behavior and security

- Opens only Student Hub V1 Admin Console at `https://student-hub.great-site.net/admin/CONSOLE/index.php?module=dashboard`.
- Uses the website's existing server-side sign-in and permissions.
- Contains no passwords, database credentials, API secrets, or embedded session data.
- Blocks cleartext HTTP and cancels SSL certificate errors.
- Requires an internet connection; this is a WebView wrapper, not an offline app.
- Changes in this project do not modify the hosted website or its database.

## Install the resulting APK

After a successful workflow, download the `Student-Hub-Admin-APK` artifact, extract `app-debug.apk` on the Android device, and install it. Debug signing keys can differ between GitHub builds. If Android refuses to update the already-installed debug app, uninstall the old app and install the new APK; sign in again afterwards.

## Build configuration

- Android application ID: `ug.studenthub.adminapp.debug` for debug builds
- Version name: `1.0.1-debug`
- Android compile SDK: 35
- Minimum Android version: API 23
- Java: 17
- Gradle: 8.9 (provided by the workflow)

A successful GitHub Actions build confirms compilation only; test login and critical admin flows on the device before relying on the new build.
