# Engineering notes — Student Hub V1 Admin Android wrapper

## Source baseline and deployment boundary

This is a standalone Android wrapper around the existing Student Hub V1 Admin Console. It does not alter `/htdocs/`, PHP endpoints, MySQL schema/data, roles, credentials, or hosting settings. V1 remains separate from V2.

## Architecture

Android WebView loads the existing HTTPS admin site. Authentication and authorization remain on the server. External hosts are routed outside the app; unknown schemes and HTTP are not trusted, and TLS certificate failures are cancelled. No JavaScript-to-native bridge or embedded backend secrets are used.

## Appearance update

- Navy and blue open-book launcher icon, including adaptive launcher icon resources.
- Branded Student Hub / Admin Console / Unite Kaliro Campus loading surface.
- A visible retry button for initial connection failures.
- App version 1.0.1, version code 2.

## Verification status

The user previously reported the initial APK opens the live console, login works, core directories open, Android Back works, and sign-out/login protection works. Those tests apply to the previously installed APK, not automatically to this new build. After compiling and installing this update, repeat login, navigation, sign-out, upload/download, and network-recovery tests. Do not treat a successful compile as a live-system QA pass.
