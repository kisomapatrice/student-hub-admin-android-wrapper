# Engineering notes — Student Hub V1 Admin app shell

## Source baseline inspected

The Library contains `V1_1.0.110.zip`. A read-only inspection found the existing admin entry point at `htdocs/admin/CONSOLE/index.php`, which already uses a responsive viewport, a collapsible sidebar/menu control, and multiple existing CSS layers. The launcher therefore reuses the hosted Admin Console rather than rebuilding its business logic.

The archive is a source snapshot, not proof that every file currently deployed in `/htdocs/` is identical. This wrapper makes no changes to production PHP, CSS, JavaScript, or the database.

## Why a WebView shell instead of a PWA

InfinityFree support posts state that PWA/service-worker installation is not supported on free hosting because the provider's browser verification system interferes with manifest and service-worker requests. Reference: https://forum.infinityfree.com/t/solution-for-pwa-progressive-web-apps/111347/2 and https://forum.infinityfree.com/t/infinityfree-does-not-support-json-files/98318/2.

The Android WebView shell is a separate Android package that displays the existing HTTPS website. It is not a native rewrite and does not make the hosted PHP app offline-capable. External sites are sent to Android's browser. The same-origin PHP backend remains responsible for all authentication and authorization.

## Security choices

- No passwords, API tokens, database credentials, or session cookies are embedded in source.
- JavaScript is enabled because the current administration console requires it; no JavaScript-to-native bridge is exposed.
- Internal top-level navigation is allow-listed to the exact HTTPS V1 hostname.
- Unknown URL schemes and plain HTTP navigation are blocked or sent outside the app.
- SSL certificate errors are cancelled, never ignored.
- WebView debugging is not enabled.
- Third-party cookies are disabled by default.
- File downloads forward a session cookie only to the exact allowed host.
- Android app backup is disabled.

## Not yet verified

This source bundle has not been compiled by an Android SDK runner in this environment, and it has not been installed or tested against the authenticated production admin pages. GitHub Actions compiles it. Live testing is required before routine administrative use.
