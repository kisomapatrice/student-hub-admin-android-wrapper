# Student Hub Admin — Android wrapper starter

This is a small Android WebView shell for the existing **Student Hub V1** administration website. It does not replace the PHP/MySQL backend or copy the website source into the app.

- Launch URL: `https://student-hub.great-site.net/admin/CONSOLE/index.php?module=dashboard`
- App name: Student Hub Admin
- Display: full app content without a browser address bar; Android status and navigation bars remain visible.
- Authentication: uses the existing Student Hub staff sign-in, permissions, and server-side session. Sign in separately inside the app; WebView cookies are separate from Chrome.
- Network: internet is required. This is not an offline app.
- Scope: only `student-hub.great-site.net` stays inside the app. Other web links open in the device browser. HTTP is not accepted for internal navigation.
- Upload/download: basic file choosing and same-host downloads are handled, but these must be tested against the live admin pages on the actual phone.

## Important hosting note

InfinityFree's support forum states that proper PWA installation/service-worker use is not supported on its free hosting because its browser-verification system interferes with those requests. This project therefore does **not** try to install a PWA on InfinityFree; it wraps the current HTTPS admin page in Android WebView instead. See `ENGINEERING_NOTES.md`.

The wrapper still needs live-device testing. In particular, InfinityFree's browser-verification layer may behave differently in Android WebView than in Chrome. If the sign-in page does not load, do not disable certificate checks or weaken the site's security; stop and diagnose the request path instead.

## Build from GitHub using a phone

The source ZIP contains the Android project and a build workflow. Because GitHub's mobile upload flow does not always preserve extracted directory structures, a separate bootstrap workflow is included at the project root as `BOOTSTRAP_WORKFLOW_TO_PASTE.yml`.

1. Create a **private** GitHub repository for this wrapper. Do not upload Student Hub's PHP source, database dump, passwords, API secrets, or admin login details.
2. Upload this ZIP file to the repository root.
3. In GitHub, choose **Add file → Create new file**. Name it `.github/workflows/build-apk.yml` and paste the contents of `BOOTSTRAP_WORKFLOW_TO_PASTE.yml`. Commit the file to the default branch.
4. Open **Actions**, select **Build Student Hub Admin APK**, choose **Run workflow**, then run it on the default branch.
5. When the run succeeds, open the run's **Artifacts** section and download `Student-Hub-Admin-APK`. Extract it on your phone and install `app-debug.apk` when Android asks.
6. Android may ask you to permit installation from the browser or file manager you used. Allow this only for the app installation you initiated, then turn the permission back off if you do not need it again.

The bootstrap build produces a debug-signed APK for personal testing, not a Google Play release. A cloud runner creates its debug signing key for that build; if the native wrapper is rebuilt later, Android may require uninstalling the old build before installing the new one. Updates to the website itself do not require rebuilding the wrapper.

## Safety and test checklist

Before relying on this for administrative work, verify on your own phone:

- The app opens the HTTPS V1 admin route and redirects logged-out users to the normal staff sign-in.
- Correct staff permissions still apply; the app does not grant roles or bypass login.
- Announcements, resources, events, opportunities, communications, and AI Guide pages open correctly.
- CSRF-protected forms submit correctly and show their normal result messages.
- Image/file chooser and download actions work where used.
- External links open outside the app; returning to Student Hub remains usable.
- Back navigation behaves safely around forms with unsaved changes.
- Sign-out actually ends the server session.

If any security page, certificate warning, login challenge, or permission error appears, stop and report the exact message. Never bypass SSL errors or share passwords with a build service.
