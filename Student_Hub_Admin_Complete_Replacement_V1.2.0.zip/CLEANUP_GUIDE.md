# Safe repository cleanup after the V1.2.0 build succeeds

Keep the Android source directories and root Gradle files. Do not delete `app/`, `settings.gradle`, `build.gradle`, or `gradle.properties`.

Once the new APK is downloaded and installed successfully, the temporary ZIP packages can be removed from the GitHub repository root:
- `Student_Hub_V1_Admin_Android_Wrapper_Starter_V1.0.zip`
- `Student_Hub_Admin_Android_Appearance_Update_V1.1.zip`
- `Student_Hub_Admin_Android_Engineered_Package_V1.1.1.zip`
- `Student_Hub_Admin_Complete_Replacement_V1.2.0.zip` (the workflow removes this automatically after a successful build/commit).

Keep one authoritative build workflow: `.github/workflows/build-apk.yml`. The temporary upgrade workflow `.github/workflows/apply-appearance-update.yml` removes itself after the successful migration. Remove other stale workflow files only after reviewing their names and confirming they are not used.
