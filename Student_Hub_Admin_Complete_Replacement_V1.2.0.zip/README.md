# Student Hub Admin Android — Clean Replacement V1.2.0

A full Android Gradle project for the Student Hub V1 Admin Console wrapper. It does not contain the website backend or database.

## Included improvements
- Branded navy/blue open-book launcher icon (adaptive icon and density-specific PNGs).
- Branded native launch screen showing Student Hub, Admin Console, Unite Kaliro Campus, connection progress, a retry action on first-load failure, and version 1.2.0.
- Clean rebuild in GitHub Actions, so stale Gradle build output cannot be reused.
- Clear, unique artifact name: `Student-Hub-Admin-v1.2.0-APK`.
- Existing WebView safety boundaries retained: HTTPS V1 host only in-app, external links opened outside, TLS errors never bypassed, no embedded credentials.

## Destination and boundaries
- Website: `https://student-hub.great-site.net`
- Launch route: `/admin/CONSOLE/index.php?module=dashboard`
- This Android project does not modify the live `/htdocs/` website or its database.
- V1 is not mixed with Student Hub V2.

## Build
The default workflow is `.github/workflows/build-apk.yml`. It builds the repository source directly and uploads artifact `Student-Hub-Admin-v1.2.0-APK`.

A successful build confirms compilation only. Install and test the APK on the device before using it for admin work. A new GitHub runner can generate a different debug signing key; Android may require uninstalling a prior debug app before installing the new APK. Save the APK and confirm you can log in before uninstalling the old one.
