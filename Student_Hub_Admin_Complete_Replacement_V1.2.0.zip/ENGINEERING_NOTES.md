# Engineering notes — V1 Android wrapper V1.2.0

## Scope
This package contains only the Android client wrapper. It is not a PHP or MySQL deployment package. No live website files, passwords, session tokens, or database credentials are included.

## Source changes in V1.2.0
- Application version code: 3; version name: 1.2.0.
- Native branded launch overlay and initial-load retry action in `MainActivity.java`.
- Navy/blue open-book icon resources and density-specific launcher PNGs.
- The build workflow performs a clean Gradle build and uploads a uniquely named versioned artifact.

## Security
- Only `https://student-hub.great-site.net` stays in the WebView.
- HTTP is not accepted as internal navigation. TLS certificate failures are cancelled, never ignored.
- External links are handed to Android's external app/browser.
- No JavaScript-to-native bridge, secrets, or authentication bypass is included.

## Verification statement
The source package was inspected for expected files and version markers and its ZIP integrity was checked. Actual Android compilation must be confirmed by GitHub Actions. Device behavior must be retested after installing the new artifact.
