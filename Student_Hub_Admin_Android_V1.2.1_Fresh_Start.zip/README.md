# Student Hub Admin Android — Fresh Start V1.2.1

This is the complete Android project source for a native Android WebView wrapper around the existing Student Hub V1 Admin Console.

## What it opens

`https://student-hub.great-site.net/admin/CONSOLE/index.php?module=dashboard`

The wrapper does not contain website files, database credentials, login credentials, or a login bypass. Authentication remains on the existing website. This package does not deploy or alter the live website, database, or AI Worker.

## Why V1.2.1 has a new package ID

The Android app ID is `ug.studenthub.adminapp.v121`. This is intentionally distinct from older builds so the fresh recovery build can be installed alongside the older working app instead of colliding with it. Keep the older app installed until you have tested the new one.

## Build with GitHub Actions

1. Ensure the project folders and root Gradle files are in the repository.
2. Use `.github/workflows/build-apk.yml` as the single authoritative Android build workflow.
3. In GitHub, open **Actions → Build Student Hub Admin Android v1.2.1 → Run workflow**.
4. When it succeeds, open that run's **Artifacts** section and download `Student-Hub-Admin-v1.2.1-APK`.
5. Extract the downloaded artifact ZIP to obtain `app-debug.apk`; the artifact ZIP itself is not the APK installer.
6. Install the APK on the phone and test the login page before considering removal of the older app.

The workflow validates the APK's ZIP structure, Android signature, package ID, version, and SHA-256 checksum. It deliberately does not require the APK to exceed an arbitrary 1 MB threshold: small Android APKs can be legitimate.

## Requirements

- GitHub Actions runner with internet access
- Java 17
- Android SDK platform 35 and build tools 35.0.0
- Gradle 8.9

The GitHub Actions workflow installs these build tools for you. This archive is source code, not a prebuilt installer APK.
