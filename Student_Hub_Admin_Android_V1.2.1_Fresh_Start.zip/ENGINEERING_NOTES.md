# Engineering notes — Student Hub Admin Android V1.2.1

## Scope
- App: native Android WebView wrapper for the Student Hub V1 Admin Console.
- Start URL: `https://student-hub.great-site.net/admin/CONSOLE/index.php?module=dashboard`.
- Application ID: `ug.studenthub.adminapp.v121`.
- Version code: 4; version name: 1.2.1.

## Key behavior
- Branded navy/blue startup overlay and retry on initial connection failure.
- JavaScript, DOM storage, cookies, upload file chooser, downloads, and Android Back behavior.
- Only the Student Hub V1 host is kept inside the WebView; other web hosts are opened externally.
- TLS certificate errors are cancelled; there is no SSL bypass.
- No JavaScript-to-native bridge and no embedded admin credentials.

## Build checks
GitHub Actions performs a clean Gradle build, tests APK ZIP integrity, verifies the APK signature, confirms package ID/version metadata, and calculates SHA-256. Passing the workflow confirms build/package checks; device sign-in and behavior must still be tested on the Samsung phone.

## Project boundaries
This package contains no PHP/MySQL backend and does not change `/htdocs/`, either database, or the separate Student Hub V2 site.
